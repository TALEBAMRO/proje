package freightos;


import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;


public class VendingMachineTest {

    private static VendingMachine vm;

    public VendingMachineTest() {
    }

    @BeforeClass
    public static void setUpClass() {
        vm = new SnackVendingMachine();
    }

    @AfterClass
    public static void tearDownClass() {
        vm = null;
    }

    @Test
    public void testBuyItemWithExactPrice() {
        long price = vm.selectItemAndGetPrice(Item.ROW_11.getName()); //price should be 10c
        assertEquals(Item.ROW_11.getPrice(), price); //10c
        vm.insertMoney(Money.TEN_C);
        List<Money> change = vm.collectItemAndChange();
        assertTrue(change.isEmpty());
    }

    @Test
    public void testBuyItemWithMorePrice() {
        long price = vm.selectItemAndGetPrice(Item.ROW_15.getName());
        assertEquals(Item.ROW_15.getPrice(), price);
        vm.insertMoney(Money.FIFTY_C);
        List<Money> change = vm.collectItemAndChange();
        assertTrue(!change.isEmpty());
        assertEquals(50 - Item.ROW_15.getPrice(), getTotal(change));

    }

    @Test(expected = SoldOutException.class)
    public void testSoldOut() {
        for (int i = 0; i < 5; i++) {
            vm.selectItemAndGetPrice(Item.ROW_15.getName());
            vm.insertMoney(Money.TEN_C);
            vm.collectItemAndChange();
        }
    }
    
    

    private long getTotal(List<Money> change) {
        long total = 0;
        for (Money c : change) {
            total = total + c.getValue();
        }
        return total;
    }

}