package freightos;

import java.util.ArrayList;

public enum Money {
    TEN_C(10), TWENTY_C(20), FIFTY_C(50), ONE(100), TWENTY(2000), FIFTY(5000), CARD(100000);

    private final String currency = "USD";
    private final int value;

    Money(int value) {
        this.value = value;
    }

    public int getValue() {
        return this.value;
    }

    public static ArrayList<Money> extarctValueFromString(String input) {
        String[] splitedString = input.split(" ");
        ArrayList<Money> enteredValues = new ArrayList<Money>();

        for (int i = 0; i < splitedString.length; i++) {
            if (splitedString[i].equalsIgnoreCase("10C")) {
                enteredValues.add(TEN_C);
            } else if (splitedString[i].equalsIgnoreCase("20c")) {
                enteredValues.add(TWENTY_C);
            } else if (splitedString[i].equalsIgnoreCase("50c")) {
                enteredValues.add(FIFTY_C);
            } else if (splitedString[i].equalsIgnoreCase("1$")) {
                enteredValues.add(ONE);
            } else if (splitedString[i].equalsIgnoreCase("20$")) {
                enteredValues.add(TWENTY);
            } else if (splitedString[i].equalsIgnoreCase("50$")) {
                enteredValues.add(FIFTY);
            } else if (splitedString[i].equalsIgnoreCase("Card")) {
                enteredValues.add(CARD);
            }
        }
        return enteredValues;
    }
}
